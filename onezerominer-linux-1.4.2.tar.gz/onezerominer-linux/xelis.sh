#!/bin/bash

./onezerominer -a xelis -w xel:zc0tqcru5sc8ry23e3ry7qk908g9aeqtvlmgahedkzgmcmrcqgyqqpu54e3 -o ssl://eu.xel.k1pool.com:9352 --worker rig_name